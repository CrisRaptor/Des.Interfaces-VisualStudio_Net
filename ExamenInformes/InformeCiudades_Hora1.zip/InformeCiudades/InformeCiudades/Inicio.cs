﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InformeCiudades
{
    public partial class Inicio : Form
    {
        public Inicio()
        {
            InitializeComponent();
            if (comboBox1 != null)
            {
                comboBox1.SelectedIndex = 0;
            }
        }

        private void Inicio_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Ciudades ciudadesForm = new Ciudades();
            if (comboBox1 != null)
            {
                string ruta = Directory.GetParent(Directory.GetParent(Directory.GetCurrentDirectory()).ToString()).ToString()+ "\\Data\\" + comboBox1.Items[comboBox1.SelectedIndex].ToString();

                ciudadesForm.Titulo = (textBox1.Text != "" )?textBox1.Text:"Reporte de ciudad";
                ciudadesForm.CiudadesGrandes = checkBox1.Checked;
                string zonaHoraria = "";
                foreach (RadioButton radioButton in groupBox1.Controls.OfType<RadioButton>())
                {
                    if (radioButton.Checked)
                    {
                        zonaHoraria = radioButton.Checked.ToString();
                    }
                }
                ciudadesForm.ZonaHoraria = "America/"+zonaHoraria;
                List<Ciudad> listaCiudades = leerCsv(ruta);
                ciudadesForm.listaCiudades = listaCiudades;
                ciudadesForm.Show();
            }
        }

        private List<Ciudad> leerCsv(string ruta)
        {
            List<Ciudad> ciudades = File.ReadAllLines(ruta).Skip(1).Select(v => ciudadDesdeCsv(v)).ToList();
            return ciudades;
        }

        private Ciudad ciudadDesdeCsv(string linea)
        {
            string[] csv = linea.Split(';');
            Ciudad ciudad = new Ciudad();
            ciudad.Name = csv[0];
            ciudad.Latitude = csv[1];
            ciudad.Longitude = csv[2];
            ciudad.Population = int.Parse(csv[3]);
            ciudad.Timezone = csv[4];
            return ciudad;
        }
    }
}
