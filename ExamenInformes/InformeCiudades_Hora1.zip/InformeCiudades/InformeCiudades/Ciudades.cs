﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InformeCiudades
{
    public partial class Ciudades : Form
    {
        public List<Ciudad> listaCiudades { get; set; }
        public string Titulo { get; set; }
        public bool CiudadesGrandes { get; set; }
        public string ZonaHoraria { get; set; }

        

        public Ciudades()
        {
            InitializeComponent();
        }

        private void Ciudades_Load(object sender, EventArgs e)
        {

            this.reportViewer1.RefreshReport();
        }
    }
}
