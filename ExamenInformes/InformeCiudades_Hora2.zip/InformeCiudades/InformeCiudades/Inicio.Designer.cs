﻿namespace InformeCiudades
{
    partial class Inicio
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Inicio));
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.groupTimeZone = new System.Windows.Forms.GroupBox();
            this.buttonResetZonaHoraria = new System.Windows.Forms.Button();
            this.radioChicago = new System.Windows.Forms.RadioButton();
            this.radioLosAngeles = new System.Windows.Forms.RadioButton();
            this.radioNewYork = new System.Windows.Forms.RadioButton();
            this.checkBoxCiudadesGrandes = new System.Windows.Forms.CheckBox();
            this.labelCiudadesGrandes = new System.Windows.Forms.Label();
            this.labelBuscarCiudad = new System.Windows.Forms.Label();
            this.textBoxBuscarCiudad = new System.Windows.Forms.TextBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.groupTimeZone.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(221, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Ciudades americanas";
            // 
            // button1
            // 
            this.button1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(60, 218);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(180, 23);
            this.button1.TabIndex = 1;
            this.button1.Text = "Mostrar las ciudades";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // groupTimeZone
            // 
            this.groupTimeZone.Controls.Add(this.buttonResetZonaHoraria);
            this.groupTimeZone.Controls.Add(this.radioChicago);
            this.groupTimeZone.Controls.Add(this.radioLosAngeles);
            this.groupTimeZone.Controls.Add(this.radioNewYork);
            this.groupTimeZone.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupTimeZone.Location = new System.Drawing.Point(17, 64);
            this.groupTimeZone.Name = "groupTimeZone";
            this.groupTimeZone.Size = new System.Drawing.Size(117, 128);
            this.groupTimeZone.TabIndex = 2;
            this.groupTimeZone.TabStop = false;
            this.groupTimeZone.Text = "Zona horaria";
            // 
            // buttonResetZonaHoraria
            // 
            this.buttonResetZonaHoraria.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonResetZonaHoraria.Location = new System.Drawing.Point(6, 100);
            this.buttonResetZonaHoraria.Name = "buttonResetZonaHoraria";
            this.buttonResetZonaHoraria.Size = new System.Drawing.Size(97, 23);
            this.buttonResetZonaHoraria.TabIndex = 9;
            this.buttonResetZonaHoraria.Text = "Desmarcar";
            this.buttonResetZonaHoraria.UseVisualStyleBackColor = true;
            this.buttonResetZonaHoraria.Click += new System.EventHandler(this.buttonResetZonaHoraria_Click);
            // 
            // radioChicago
            // 
            this.radioChicago.AutoSize = true;
            this.radioChicago.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioChicago.Location = new System.Drawing.Point(7, 74);
            this.radioChicago.Name = "radioChicago";
            this.radioChicago.Size = new System.Drawing.Size(78, 20);
            this.radioChicago.TabIndex = 2;
            this.radioChicago.TabStop = true;
            this.radioChicago.Text = "Chicago";
            this.radioChicago.UseVisualStyleBackColor = true;
            // 
            // radioLosAngeles
            // 
            this.radioLosAngeles.AutoSize = true;
            this.radioLosAngeles.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioLosAngeles.Location = new System.Drawing.Point(7, 49);
            this.radioLosAngeles.Name = "radioLosAngeles";
            this.radioLosAngeles.Size = new System.Drawing.Size(107, 20);
            this.radioLosAngeles.TabIndex = 1;
            this.radioLosAngeles.TabStop = true;
            this.radioLosAngeles.Text = "Los_Angeles";
            this.radioLosAngeles.UseVisualStyleBackColor = true;
            // 
            // radioNewYork
            // 
            this.radioNewYork.AutoSize = true;
            this.radioNewYork.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioNewYork.Location = new System.Drawing.Point(7, 22);
            this.radioNewYork.Name = "radioNewYork";
            this.radioNewYork.Size = new System.Drawing.Size(90, 20);
            this.radioNewYork.TabIndex = 0;
            this.radioNewYork.TabStop = true;
            this.radioNewYork.Text = "New_York";
            this.radioNewYork.UseVisualStyleBackColor = true;
            // 
            // checkBoxCiudadesGrandes
            // 
            this.checkBoxCiudadesGrandes.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.checkBoxCiudadesGrandes.AutoSize = true;
            this.checkBoxCiudadesGrandes.Location = new System.Drawing.Point(140, 163);
            this.checkBoxCiudadesGrandes.Name = "checkBoxCiudadesGrandes";
            this.checkBoxCiudadesGrandes.Size = new System.Drawing.Size(140, 20);
            this.checkBoxCiudadesGrandes.TabIndex = 3;
            this.checkBoxCiudadesGrandes.Text = "Ciudades grandes";
            this.checkBoxCiudadesGrandes.UseVisualStyleBackColor = true;
            // 
            // labelCiudadesGrandes
            // 
            this.labelCiudadesGrandes.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.labelCiudadesGrandes.AutoSize = true;
            this.labelCiudadesGrandes.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCiudadesGrandes.Location = new System.Drawing.Point(161, 142);
            this.labelCiudadesGrandes.Name = "labelCiudadesGrandes";
            this.labelCiudadesGrandes.Size = new System.Drawing.Size(119, 16);
            this.labelCiudadesGrandes.TabIndex = 4;
            this.labelCiudadesGrandes.Text = "Filtro de tamaño";
            this.labelCiudadesGrandes.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // labelBuscarCiudad
            // 
            this.labelBuscarCiudad.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.labelBuscarCiudad.AutoSize = true;
            this.labelBuscarCiudad.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelBuscarCiudad.Location = new System.Drawing.Point(165, 70);
            this.labelBuscarCiudad.Name = "labelBuscarCiudad";
            this.labelBuscarCiudad.Size = new System.Drawing.Size(120, 16);
            this.labelBuscarCiudad.TabIndex = 5;
            this.labelBuscarCiudad.Text = "Ciudad buscada";
            // 
            // textBoxBuscarCiudad
            // 
            this.textBoxBuscarCiudad.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxBuscarCiudad.Location = new System.Drawing.Point(164, 91);
            this.textBoxBuscarCiudad.Name = "textBoxBuscarCiudad";
            this.textBoxBuscarCiudad.Size = new System.Drawing.Size(106, 22);
            this.textBoxBuscarCiudad.TabIndex = 6;
            // 
            // comboBox1
            // 
            this.comboBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "CiudadesEEUU.csv"});
            this.comboBox1.Location = new System.Drawing.Point(72, 37);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(179, 24);
            this.comboBox1.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(14, 40);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 16);
            this.label4.TabIndex = 8;
            this.label4.Text = "Datos:";
            // 
            // Inicio
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(282, 253);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.textBoxBuscarCiudad);
            this.Controls.Add(this.labelBuscarCiudad);
            this.Controls.Add(this.labelCiudadesGrandes);
            this.Controls.Add(this.checkBoxCiudadesGrandes);
            this.Controls.Add(this.groupTimeZone);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Inicio";
            this.Text = "Reporte de ciudades";
            this.Load += new System.EventHandler(this.Inicio_Load);
            this.groupTimeZone.ResumeLayout(false);
            this.groupTimeZone.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox groupTimeZone;
        private System.Windows.Forms.RadioButton radioChicago;
        private System.Windows.Forms.RadioButton radioLosAngeles;
        private System.Windows.Forms.RadioButton radioNewYork;
        private System.Windows.Forms.CheckBox checkBoxCiudadesGrandes;
        private System.Windows.Forms.Label labelCiudadesGrandes;
        private System.Windows.Forms.Label labelBuscarCiudad;
        private System.Windows.Forms.TextBox textBoxBuscarCiudad;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button buttonResetZonaHoraria;
    }
}

